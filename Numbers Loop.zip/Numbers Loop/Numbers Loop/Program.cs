﻿using System;

namespace NumbersLoop
{
    class Program
    {
        static void Main(string[] args)
        {
            Random rand = new Random();
            int[] numbers = new int[10];
            int evenNumber = 0;
            for (int i = 0; i < numbers.Length; i++)
            {
                numbers[i] = rand.Next(1, 50);
                Console.Write(numbers[i] + " ");
                if (numbers[i] % 2 == 0)
                {
                    evenNumber++;
                }
            }
            Console.WriteLine();
            Console.WriteLine(evenNumber);
        }
    }
}
