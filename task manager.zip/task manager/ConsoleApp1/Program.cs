﻿using System;
using System.Data.SqlTypes;
using System.Diagnostics.CodeAnalysis;

class ConsoleApp1
{
    static void Main(string[] args)
    {
        List<string> tasks = new List<string>();
        Console.Write("Please enter what you want to do:\n1-add\n2-remove\n3-find by name\n4-mark as done\n");
        while (true)
        {
            string UserInput;
            switch (Convert.ToInt32(Console.ReadLine()))
            {
                case 1:
                    Console.Write("Write a task you want to add ");
                    UserInput = Console.ReadLine();
                    tasks.Add(UserInput);
                    Console.WriteLine("task " + UserInput + " got added");
                    break;
                case 2:
                    Console.WriteLine("Write task you want to delete");
                    UserInput = Console.ReadLine();
                    tasks.Remove(UserInput);
                    Console.WriteLine($"{UserInput} is deleted");
                    break;
                case 3:
                    Console.Write("Enter a task, you want to find ");
                    UserInput = Console.ReadLine();
                    foreach (string task in tasks)
                    {
                        if (task == UserInput)
                        {
                            Console.WriteLine($"task number is {task.IndexOf(UserInput) + 2}");
                        }
                    }

                    ;
                    break;
                case 4:
                    Console.Write("Enter a task, you want to mark as done ");
                    UserInput = Console.ReadLine();
                    for (int i = 0; i < tasks.Count; i++)
                    {
                        if (tasks[i] == UserInput)
                        {
                            tasks[i] = "Done " + tasks[i];
                        } 
            }
                    break;
        }
            foreach (var task in tasks)
            {
                Console.WriteLine($"task, number {tasks.IndexOf(task)+1 } " + task);
            }
        }
    }
}