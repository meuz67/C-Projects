﻿using System;
class ConsoleApp1 {
    static void Main() {
        Random rand = new Random();
        string[] word = new string[rand.Next(1, 10)];
        string[] alphabet = {"a", "b",  "c", "d", "e", "f", "g", "h", "i", "j",  "k", "l", 
            "m", "n", "o", "p", 
            "q", "r", "s", "t", "u", "v", "w", "x", "y", "z"};
        Console.WriteLine();
        for (int i = 0; i < word.Length; i++)
        {
            word[i] = alphabet[rand.Next(0, alphabet.Length)];
            Console.Write(word[i]);
        }
    }
}