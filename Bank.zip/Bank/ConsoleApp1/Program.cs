﻿using System;
using System.Security.Cryptography;

class ConsoleApp1
{
    static void Main()
    {
        Console.Write("Write your money: ");
        int money = Convert.ToInt32(Console.ReadLine());
        while (true)
        {
            Console.WriteLine("1-showbalance\n2-deposit\n3-withdraw");
            switch (Convert.ToInt32(Console.ReadLine()))
            {
                case 1:
                    ShowBalance(money);
                    break;
                case 2:
                    Console.Write("Write percentage: ");
                    int percentage = Convert.ToInt32(Console.ReadLine());
                    Console.Write("Write years: ");
                    int years = Convert.ToInt32(Console.ReadLine());
                    Deposit(money, percentage, years);
                    break;
                case 3:
                    Console.Write("Write withdraw amount: ");
                    int withdrawAmount = Convert.ToInt32(Console.ReadLine());
                    WithDraw(money, withdrawAmount);
                    break;
            }
        }
}

    static void ShowBalance(int money)
    {
        int Money = money;
        Console.WriteLine($"Your balance is: {Money}");
    }

    static void Deposit(int money, int percentage, int years)
    {
        money += years*(money * percentage / 100);
        Console.WriteLine(money);
    }

    static void WithDraw(int money, int withdrawAmount)
    {
        money -= withdrawAmount;
        Console.WriteLine($"Your withdrawal is: {withdrawAmount}");
    }
}