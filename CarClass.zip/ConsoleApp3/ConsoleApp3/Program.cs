﻿using System;
class ConsoleApp1 {
    class Car
    {
        public string Name;
        public int Year;
        public bool IsDriving;
    }
    static void Main() {
        Car car = new Car();
        car.Name = "Toyota";
        car.Year = 2009;
        car.IsDriving = false;
        Drive(car.Name, car.Year, car.IsDriving);
    }

    static void Drive(string Name, int Year, bool IsDriving)
    {
        string name = Name;
        int year = Year;
        if (IsDriving)
        {
            Console.WriteLine($"{name}, which was made in {Year} is dring");
        }
        else
        {
            Console.WriteLine($"{name}, which was made in {Year} isn`t driving");
        }
    }
}