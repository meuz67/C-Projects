﻿using System;
using System.Collections.Generic;

class Book
{
    public string Title { get; set; }
    public string Author { get; set; }
    public int Year { get; set; }

    public string GetInfo()
    {
        return $"{Title} by {Author}, published in {Year}";
    }
}

class Library
{
    private List<Book> books = new List<Book>();

    public void AddBook(Book book)
    {
        books.Add(book);
        Console.WriteLine("Book added!");
    }

    public void RemoveBook(string title)
    {
        books.RemoveAll(b => b.Title == title);
        Console.WriteLine("Book removed (if it existed).");
    }

    public Book FindBook(string title)
    {
        return books.Find(b => b.Title == title);
    }

    public void ShowAllBooks()
    {
        if (books.Count == 0)
        {
            Console.WriteLine("No books in the library.");
            return;
        }
        foreach (var book in books)
        {
            Console.WriteLine(book.GetInfo());
        }
    }
}

class Program
{
    static void Main()
    {
        Library library = new Library();
        bool running = true;

        while (running)
        {
            ShowMenu();
            string choice = Console.ReadLine();

            switch (choice)
            {
                case "1":
                    Console.Write("Enter title: ");
                    string title = Console.ReadLine();
                    Console.Write("Enter author: ");
                    string author = Console.ReadLine();
                    Console.Write("Enter year: ");
                    int year = int.Parse(Console.ReadLine());

                    library.AddBook(new Book { Title = title, Author = author, Year = year });
                    break;

                case "2":
                    Console.Write("Enter title to remove: ");
                    string removeTitle = Console.ReadLine();
                    library.RemoveBook(removeTitle);
                    break;

                case "3":
                    Console.Write("Enter title to find: ");
                    string findTitle = Console.ReadLine();
                    var found = library.FindBook(findTitle);
                    Console.WriteLine(found != null ? found.GetInfo() : "Book not found.");
                    break;

                case "4":
                    library.ShowAllBooks();
                    break;

                case "5":
                    running = false;
                    Console.WriteLine("Exiting...");
                    break;
                default:
                    Console.WriteLine("Invalid choice, try again.");
                    break;
            }
        }
    }

    static void ShowMenu()
    {
        Console.WriteLine("\n--- Library Menu ---");
        Console.WriteLine("1. Add Book");
        Console.WriteLine("2. Remove Book");
        Console.WriteLine("3. Find Book");
        Console.WriteLine("4. Show All Books");
        Console.WriteLine("5. Exit");
        Console.Write("Choose an option: ");
    }
}
