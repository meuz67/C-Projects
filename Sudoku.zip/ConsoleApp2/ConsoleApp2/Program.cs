﻿using System;

namespace SudokuApp
{
    class SudokuBoard
    {
        public int[,] Grid { get; private set; }

        public SudokuBoard()
        {
            Grid = new int[9, 9];
        }

        public void PrintBoard()
        {
            for (int i = 0; i < 9; i++)
            {
                if (i % 3 == 0 && i != 0)
                    Console.WriteLine("------+-------+------");

                for (int j = 0; j < 9; j++)
                {
                    if (j % 3 == 0 && j != 0)
                        Console.Write("| ");

                    Console.Write(Grid[i, j] == 0 ? ". " : Grid[i, j] + " ");
                }
                Console.WriteLine();
            }
        }

        public bool IsValidMove(int row, int col, int num)
        {
            for (int j = 0; j < 9; j++)
                if (Grid[row, j] == num) return false;

            for (int i = 0; i < 9; i++)
                if (Grid[i, col] == num) return false;

            int startRow = row - row % 3;
            int startCol = col - col % 3;
            for (int i = 0; i < 3; i++)
                for (int j = 0; j < 3; j++)
                    if (Grid[startRow + i, startCol + j] == num) return false;

            return true;
        }

        public bool IsSolved()
        {
            for (int i = 0; i < 9; i++)
                for (int j = 0; j < 9; j++)
                    if (Grid[i, j] == 0) return false;
            return true;
        }

        public bool Solve()
        {
            for (int i = 0; i < 9; i++)
            {
                for (int j = 0; j < 9; j++)
                {
                    if (Grid[i, j] == 0)
                    {
                        for (int num = 1; num <= 9; num++)
                        {
                            if (IsValidMove(i, j, num))
                            {
                                Grid[i, j] = num;
                                if (Solve())
                                    return true;
                                Grid[i, j] = 0;
                            }
                        }
                        return false;
                    }
                }
            }
            return true;
        }

        public bool ValidateBoard()
        {
            for (int i = 0; i < 9; i++)
            {
                bool[] rowCheck = new bool[10];
                bool[] colCheck = new bool[10];

                for (int j = 0; j < 9; j++)
                {
                    int rowVal = Grid[i, j];
                    int colVal = Grid[j, i];

                    if (rowVal != 0)
                    {
                        if (rowCheck[rowVal]) return false;
                        rowCheck[rowVal] = true;
                    }

                    if (colVal != 0)
                    {
                        if (colCheck[colVal]) return false;
                        colCheck[colVal] = true;
                    }
                }
            }

            for (int row = 0; row < 9; row += 3)
            {
                for (int col = 0; col < 9; col += 3)
                {
                    bool[] boxCheck = new bool[10];
                    for (int i = 0; i < 3; i++)
                    {
                        for (int j = 0; j < 3; j++)
                        {
                            int val = Grid[row + i, col + j];
                            if (val != 0)
                            {
                                if (boxCheck[val]) return false;
                                boxCheck[val] = true;
                            }
                        }
                    }
                }
            }

            return true;
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            SudokuBoard board = new SudokuBoard();
            bool exit = false;

            while (!exit)
            {
                Console.Clear();
                Console.WriteLine("=== Sudoku Console App ===");
                board.PrintBoard();
                Console.WriteLine("\nMenu:");
                Console.WriteLine("1. Enter a number");
                Console.WriteLine("2. Validate board");
                Console.WriteLine("3. Solve automatically");
                Console.WriteLine("4. Exit");
                Console.Write("Choose an option: ");

                string choice = Console.ReadLine();

                switch (choice)
                {
                    case "1":
                        Console.Write("Enter row (0-8): ");
                        int row = int.Parse(Console.ReadLine());
                        Console.Write("Enter column (0-8): ");
                        int col = int.Parse(Console.ReadLine());
                        Console.Write("Enter number (1-9): ");
                        int num = int.Parse(Console.ReadLine());

                        if (board.IsValidMove(row, col, num))
                        {
                            board.Grid[row, col] = num;
                            Console.WriteLine("Move accepted!");
                        }
                        else
                        {
                            Console.WriteLine("Invalid move!");
                        }
                        Console.ReadKey();
                        break;

                    case "2":
                        Console.WriteLine(board.ValidateBoard()
                            ? "Board is valid."
                            : "Board is invalid!");
                        Console.ReadKey();
                        break;

                    case "3":
                        if (board.Solve())
                            Console.WriteLine("Solved successfully!");
                        else
                            Console.WriteLine("No solution found.");
                        Console.ReadKey();
                        break;

                    case "4":
                        exit = true;
                        break;

                    default:
                        Console.WriteLine("Invalid choice!");
                        Console.ReadKey();
                        break;
                }
            }
        }
    }
}
