﻿using System;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.CursorVisible = false;
            char[] bag = new char[0];
            char[,] map =
            {
                { '#', '#', '#', '#', '#', '#', '#' },
                { ' ', ' ', ' ', ' ', ' ', 'x', ' ' },
                { ' ', ' ', ' ', '#', ' ', '#', ' ' },
                { ' ', ' ', ' ', '#', ' ', '#', 'x' },
                { ' ', 'x', ' ', '#', ' ', ' ', ' ' },
                { '#', '#', '#', '#', '#', '#', '#' }
            };

            int userx = 2;
            int usery = 2;

            while (true)
            {
                Console.SetCursorPosition(0, 0);
                Console.Write("Bag: ");
                for (int b = 0; b < bag.Length; b++)
                {
                    Console.Write(bag[b] + " ");
                }

                Console.WriteLine();

                for (int i = 0; i < map.GetLength(0); i++)
                {
                    for (int j = 0; j < map.GetLength(1); j++)
                    {
                        Console.Write(map[i, j] + " ");
                    }

                    Console.WriteLine();
                }

                Console.SetCursorPosition(userx * 2, usery + 1);
                Console.Write("@");

                ConsoleKeyInfo charKey = Console.ReadKey(true);

                switch (charKey.Key)
                {
                    case ConsoleKey.UpArrow:
                        if (map[usery - 1, userx] != '#')
                            usery--;
                        break;

                    case ConsoleKey.DownArrow:
                        if (map[usery + 1, userx] != '#')
                            usery++;
                        break;

                    case ConsoleKey.LeftArrow:
                        if (map[usery, userx - 1] != '#')
                            userx--;
                        break;

                    case ConsoleKey.RightArrow:
                        if (map[usery, userx + 1] != '#')
                            userx++;
                        break;
                        if (map[usery, userx] == 'x')
                        {
                            map[usery, userx] = 'O'; 
                            Array.Resize(ref bag, bag.Length + 1);
                            bag[bag.Length - 1] = 'x'; 
                        }
                }

            }
        }
    }
}
