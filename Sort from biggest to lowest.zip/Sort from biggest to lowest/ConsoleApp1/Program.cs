﻿using System;

class ConsoleApp1
{
    static void Main()
    {
        int[] numbers = new int[10];
        Random rand = new Random();
        for (int i = 0; i < numbers.Length; i++)
        {
            numbers[i] = rand.Next(1, 100);
            
        }
        Console.Write("Unsorted array: ");
        foreach (int number in numbers)
        {
            Console.Write(number + " ");
        }

        Array.Sort(numbers);
        Array.Reverse(numbers);
        Console.WriteLine();
        Console.Write("Sorted array (from biggest to lowest):");
        foreach (var item in numbers)
        {
            Console.Write(item + " ");
        }
    }
}