﻿using System;
using System.Reflection.Metadata;

public class ConsoleApp1
{
    public static void Main(string[] args)
    {
        bool isOpen = true;
        Table[] tables =
        {
            new Table(1, 2),
            new Table(2, 4),
            new  Table(3, 6),
        };
        while (isOpen)
        {
            Console.WriteLine("Cafe admin");
            for (int i = 0; i < tables.Length; i++) 
            {
                tables[i].ShowInfo();
            }
            Console.Write("\nSelect table number ");
            int wishTable = Convert.ToInt32(Console.ReadLine()) - 1;
            Console.Write("\nSelect how many seats you need ");
            int wishNumberOfSeats = Convert.ToInt32(Console.ReadLine()) - 1;
            bool isReservation = tables[wishTable].Reserve(wishNumberOfSeats);
            if (isReservation)
            {
                Console.WriteLine("Reservation successful");
            }
            else
            {
                Console.WriteLine("Reservation failed");
            }
            Console.ReadKey();
            Console.Clear();
        }
    }

    class Table
    {
        public int number;
        public int maxPlaces;
        public int FreePlaces;

        public Table(int Number, int MaxPlaces)
        {
            number = Number;
            maxPlaces = MaxPlaces;
        }

        public void ShowInfo()
        {
            Console.WriteLine($"Table {number} has {maxPlaces} places");
        }

        public bool Reserve(int places)
        {
            if (FreePlaces >= places)
            {
                FreePlaces-=places;
                return true;
            }
            else
            {
                return false;
            }
        }
}
}